
package userstatcoffee;
import cafemachine.order.CafemachineOrder;
import java.util.ArrayList;
import java.util.List;

public enum logsefareshi {
     INSTANCE;
     private List<CafemachineOrder> orders = new ArrayList<>();
     
     logsefareshi(){}
     
     public void logsefaresh (CafemachineOrder cafemachineOrder )
     {
         this.orders.add(cafemachineOrder);
     }
     
      public double getTotalSales () {
        return this.orders.stream().mapToDouble(order -> {
            return order.getPrice();
        }).sum();
    }
    
}

package biling;

import biling.residprinter;
import cafemachine.order.CafemachineOrder;


public class caferesidprint implements residprinter {
    
     private CafemachineOrder CafemachineOrder;

    private caferesidprint () {}

    public caferesidprint (CafemachineOrder CafemachineOrder) {
        this.CafemachineOrder = CafemachineOrder;
    }

  //  protected String printOrder () {
       // return lineBreak(CafemachineOrder.getCafetype() + CafemachineOrder.getcafesize() + " " + " with " +
      //          CafemachineOrder.getCondiments().stream().map(condiment -> condiment.getDisplayName() + ",").reduce("", String::concat));
    //}

    
}


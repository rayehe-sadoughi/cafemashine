
package biling;
 
public interface residprinter {
    
    public abstract class ReceiptPrinter {

    public String print () {
        StringBuilder sb = new StringBuilder();
        sb.append(printOrder());
        sb.append(printPrice());
        

        return sb.toString();
    }

   

    abstract String printOrder();

    abstract String printPrice();

  
    
}
}

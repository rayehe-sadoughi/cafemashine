
package cafemachine.order;


public interface OrderService extends OrderObservable {
      void addOrder(CafemachineOrder order);
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cafemachine.order;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;


public class CafemachineOrder implements Billable {

 private orderstate state;
    private customer customer;

    private Cafetype Cafetype;

    private cafesize  cafesize ;

    private List<condiment> condiments;

    private  CafemachineOrder() {}
    
     private CafemachineOrder ( customer customer, Cafetype Cafetype, cafesize  cafesize , List<condiment> condiments) {
        this.customer = customer;
        this.Cafetype = Cafetype;
        this.cafesize  = cafesize ;
        this.condiments = condiments;

        
    }
     
    

    public customer getcustomer () {
        return this.customer;
    }

    public List<condiment> getCondiments () {
        return condiments;
    }

    //public double getPrice () {
       // return calculate((Cafetype.getPrice() * cafesize .getNumMillimeters()) + condiments
          //  .stream().mapToDouble(condiment -> condiment.getPrice()).sum());
    //}
    
   public void addCoffee () {
        
    }

    public void addMilk () {
        
    }

    public void addCondiments () {
       
    }

    public void completeOrder () {
        
    }

 
    public cafesize  getcafesize  () {
        return cafesize ;
    }

    public Cafetype Cafetype () {
        return Cafetype;
    }

    @Override
    public String toString () {
        return "=== Coffee Order === \n" +
                cafesize + " " + Cafetype + " with " +
                condiments.stream().map(condiment -> condiment.getDisplayName() + ",").reduce("", String::concat) +
                "\nPrice: " ;
     }

    @Override
    public double getPrice() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    public cafesize getCafetype() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public static class CafemachineOrderBuilder {


        private customer customer;

        private Cafetype Cafetype;

        private cafesize  cafesize ;

        private List<condiment> condiments;

        public CafemachineOrderBuilder () {
            condiments = new ArrayList<>();
        }

        
        public CafemachineOrderBuilder setcustomer (customer customer) {
            this.customer = customer;
            return this;
        }

        public CafemachineOrderBuilder setType (Cafetype Cafetype) {
            this.Cafetype = Cafetype;
            return this;
        }

        public CafemachineOrderBuilder setSize (cafesize  cafesize ) {
            this.cafesize  = cafesize ;
            return this;
        }

        public CafemachineOrderBuilder addCondiment (condiment condiment) {
            this.condiments.add(condiment);
            return this;
        }

        /**
         *
         * @return
         */
        public   CafemachineOrder order () {
            if (customer == null || Cafetype == null || cafesize  == null) {
                throw new IllegalArgumentException();
           }

            return new CafemachineOrder ( customer, Cafetype, cafesize , condiments);
        }
    }
}
    


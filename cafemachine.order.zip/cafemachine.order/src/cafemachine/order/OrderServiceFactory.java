
package cafemachine.order;


public interface OrderServiceFactory {
    
      OrderService createOrderService ();
}

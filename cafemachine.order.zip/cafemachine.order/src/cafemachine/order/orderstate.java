
package cafemachine.order;


public enum orderstate {
      WAITING,
    COFFEE_ADDED,
    MILK_ADDED,
    CONDIMENTS_ADDED,
    COMPLETED,
    
}


package cafemachine.order;


public class customer {
    private String name;

    public customer (String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
    
}

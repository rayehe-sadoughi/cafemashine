
package cafemachine.order;


public enum orderevent {
    ADD_COFFEE,
    ADD_MILK,
    ADD_CONDIMENTS,
    COMPLETE_ORDER;
    
}

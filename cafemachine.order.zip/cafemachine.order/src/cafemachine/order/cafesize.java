
package cafemachine.order;


public enum cafesize {
    SMALL ("Small", 250),
    MEDIUM ("Medium", 350),
    LARGE ("Large", 500);

    private String displayName;
    private double numMillimeters;

    cafesize(String displayName, double numMillimeters) {
        this.displayName = displayName;
        this.numMillimeters = numMillimeters;
    }

    public String getDisplayName() {
        return displayName;
    }

    public double getNumMillimeters () {
        return numMillimeters;
    }
    
}

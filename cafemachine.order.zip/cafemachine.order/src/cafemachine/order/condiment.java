/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cafemachine.order;


public enum condiment implements Billable {
    CREAM ("Cream", 0.2d),
    MILK("Milk", 0.1d),
    SUGAR("Sugar", 0d);

    private String displayName;
    private double price;

    condiment (String displayName, double price) {
        this.displayName = displayName;
        this.price = price;
    }

    public String getDisplayName() {
        return displayName;
    }

    public double getPrice () {
        return price;
    }
    
   
    
}


package drinkmaker;
import cafemachine.order.CafemachineOrder;
public interface cafemashine extends Runnable, Makeradded{
     boolean available ();
    void start (CafemachineOrder coffeeOrder);
    String getName();
    String getLocation();
    
}

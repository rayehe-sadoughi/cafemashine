/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drinkmaker;
import cafemachine.order.CafemachineOrder;
import userstatcoffee.logsefareshi;
import java.util.ArrayList;
import java.util.List;

public class cafemaker implements cafemashine{
    
    
   private CafemachineOrder coffeeOrder;
    private List<Makeradded> observers = new ArrayList();
    private String name;
    private  String location;

       private Thread machineThread;

    private cafemaker () {}

    public cafemaker(String name, String location) {
        this.name = name;
        this.location = location;
    }

   @Override
    public boolean available () {
       return (coffeeOrder == null );
    }

    @Override
    public void start (CafemachineOrder coffeeOrder) {
        if (available()) {
            this.coffeeOrder = coffeeOrder;

            if (machineThread != null && machineThread.isAlive()) {
                machineThread.interrupt();
                
            }

            machineThread = new Thread(this);
            machineThread.start();
        }
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getLocation() {
        return location;
    }

    private void addCoffee () {
        coffeeOrder.addCoffee();
       
    }

    private void addMilk () {
        coffeeOrder.addMilk();
       
    }

    private void addCondiments() {
        coffeeOrder.addCondiments();
       
    }

    private void completeOrder () {
        coffeeOrder.completeOrder();
        
    }

    public void addObserver(cafemashine observer) {
        observers.add(observer);
    }

    public void removeObserver (cafemashine observer) {
        observers.remove(observer);
    }

    @Override
    public void run() {
        if (!available()) {
            try {
                addCoffee();
                Thread.sleep(5000);
                addMilk();
                Thread.sleep(5000);
                if  (coffeeOrder.getCondiments().size() > 0) {
                    addCondiments();
                }
                Thread.sleep(5000);
                completeOrder();
            } catch (InterruptedException exc) {
                System.out.println("Exception");
                System.out.println(exc);
            }
        }
    }

    @Override
    public void coffeeAdded(CafemachineOrder coffeeMachine, CafemachineOrder coffeeOrder) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void milkAdded(CafemachineOrder coffeeMachine, CafemachineOrder coffeeOrder) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void condimentsAdded(CafemachineOrder coffeeMachine, CafemachineOrder coffeeOrder) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void orderCompleted(CafemachineOrder coffeeMachine, CafemachineOrder coffeeOrder) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}

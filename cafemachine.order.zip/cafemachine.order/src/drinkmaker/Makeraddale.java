
package drinkmaker;


public interface Makeraddale {
      void addObserver(Makeradded observer);

    void removeObserver (Makeradded observer);
    
}
